import io
import os
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path
from typing import Tuple

import numpy as np
import vtracer
from fastapi import FastAPI, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from PIL import Image, ImageFilter, ImageOps

BASE_DIR = Path(__file__).resolve().parent.parent
APP_DIR = BASE_DIR / "app"
STATIC_DIR = APP_DIR / "static"
TEMPLATES_DIR = APP_DIR / "templates"
OUTPUT_DIR = BASE_DIR / "outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="Hybrid Anime Vectorizer")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


# -----------------------------
# Utilities
# -----------------------------

def resize_max_side(img: Image.Image, max_side: int) -> Image.Image:
    if max(img.size) <= max_side:
        return img
    ratio = max_side / max(img.size)
    new_size = (max(1, int(img.width * ratio)), max(1, int(img.height * ratio)))
    return img.resize(new_size, Image.Resampling.LANCZOS)


def save_png_bytes(img: Image.Image) -> bytes:
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def pil_from_upload(upload: UploadFile) -> Image.Image:
    img = Image.open(upload.file)
    img = ImageOps.exif_transpose(img)
    if img.mode not in ("RGB", "RGBA"):
        img = img.convert("RGBA")
    return img


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def alpha_threshold_and_shrink(alpha: Image.Image, threshold: int = 180, shrink_px: int = 1, blur: float = 0.2) -> Image.Image:
    a = alpha.convert("L")
    arr = np.array(a)
    arr = np.where(arr >= threshold, 255, 0).astype(np.uint8)
    a = Image.fromarray(arr, mode="L")
    if shrink_px > 0:
        # MinFilter on alpha works like erosion on white foreground.
        a = a.filter(ImageFilter.MinFilter(shrink_px * 2 + 1))
    if blur > 0:
        a = a.filter(ImageFilter.GaussianBlur(blur))
    return a


def color_bleed(rgb: Image.Image, alpha: Image.Image, bleed_px: int = 2) -> Image.Image:
    if bleed_px <= 0:
        rgba = rgb.convert("RGBA")
        rgba.putalpha(alpha)
        return rgba
    rgb_arr = np.array(rgb.convert("RGB"))
    alpha_arr = np.array(alpha.convert("L"))
    filled = alpha_arr > 0

    # Use a simple neighborhood propagation without OpenCV.
    for _ in range(bleed_px):
        new_rgb = rgb_arr.copy()
        # candidate ring = transparent pixels adjacent to opaque pixels
        for dy, dx in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]:
            src = np.roll(rgb_arr, shift=(dy, dx), axis=(0,1))
            src_fill = np.roll(filled, shift=(dy, dx), axis=(0,1))
            ring = (~filled) & src_fill
            new_rgb[ring] = src[ring]
        rgb_arr = new_rgb
        # expand filled by one pixel using neighbor ORs
        expanded = filled.copy()
        for dy, dx in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]:
            expanded |= np.roll(filled, shift=(dy, dx), axis=(0,1))
        filled = expanded

    rgba = Image.fromarray(rgb_arr, mode="RGB").convert("RGBA")
    rgba.putalpha(alpha)
    return rgba


def make_border_connected_bg_mask(
    rgb: Image.Image,
    neutral_max_chroma: int = 28,
    light_min: int = 145,
    force_white_min: int = 245,
    barrier_radius: int = 4,
) -> np.ndarray:
    arr = np.array(rgb.convert("RGB"))
    h, w = arr.shape[:2]
    mx = arr.max(axis=2).astype(np.int16)
    mn = arr.min(axis=2).astype(np.int16)
    chroma = mx - mn

    eligible = (((chroma <= neutral_max_chroma) & (mx >= light_min)) | (mx >= force_white_min))

    # Protect dark/colored linework areas to keep white clothing from being eaten.
    strong = (((chroma > 20) & (mx < 252)) | (mx < 120) | (mn < 90)).astype(np.uint8) * 255
    strong_img = Image.fromarray(strong, mode="L")
    if barrier_radius > 0:
        for _ in range(barrier_radius):
            strong_img = strong_img.filter(ImageFilter.MaxFilter(3))
    barrier = np.array(strong_img) > 0
    passable = eligible & (~barrier)

    bg = np.zeros((h, w), dtype=bool)
    q = []
    for x in range(w):
        if passable[0, x]:
            bg[0, x] = True
            q.append((x, 0))
        if passable[h - 1, x]:
            bg[h - 1, x] = True
            q.append((x, h - 1))
    for y in range(h):
        if passable[y, 0]:
            bg[y, 0] = True
            q.append((0, y))
        if passable[y, w - 1]:
            bg[y, w - 1] = True
            q.append((w - 1, y))

    head = 0
    while head < len(q):
        x, y = q[head]
        head += 1
        for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if 0 <= nx < w and 0 <= ny < h and passable[ny, nx] and not bg[ny, nx]:
                bg[ny, nx] = True
                q.append((nx, ny))
    return bg


def preprocess_image(
    src: Image.Image,
    max_side: int = 1800,
    remove_bg: bool = True,
    halo_fix: bool = True,
) -> Image.Image:
    src = resize_max_side(src, max_side)
    if src.mode != "RGBA":
        src = src.convert("RGBA")
    rgb = src.convert("RGB")

    if remove_bg:
        bg = make_border_connected_bg_mask(rgb)
        alpha_arr = (~bg).astype(np.uint8) * 255
        alpha = Image.fromarray(alpha_arr, mode="L")
    else:
        alpha = src.getchannel("A") if src.mode == "RGBA" else Image.new("L", src.size, 255)

    if halo_fix:
        alpha = alpha_threshold_and_shrink(alpha, threshold=180, shrink_px=1, blur=0.2)
        rgba = color_bleed(rgb, alpha, bleed_px=2)
    else:
        rgba = rgb.convert("RGBA")
        rgba.putalpha(alpha)

    bbox = rgba.getchannel("A").getbbox()
    if bbox:
        pad = 12
        left = max(0, bbox[0] - pad)
        top = max(0, bbox[1] - pad)
        right = min(rgba.width, bbox[2] + pad)
        bottom = min(rgba.height, bbox[3] + pad)
        rgba = rgba.crop((left, top, right, bottom))
    return rgba


def preset_to_vtracer(preset: str):
    if preset == "speed":
        return dict(filter_speckle=4, color_precision=6, layer_difference=16, corner_threshold=60, length_threshold=5.0, max_iterations=10, splice_threshold=45, path_precision=2)
    if preset == "quality":
        return dict(filter_speckle=2, color_precision=8, layer_difference=8, corner_threshold=60, length_threshold=3.0, max_iterations=12, splice_threshold=45, path_precision=3)
    return dict(filter_speckle=3, color_precision=7, layer_difference=12, corner_threshold=58, length_threshold=4.0, max_iterations=11, splice_threshold=45, path_precision=2)


def run_vtracer(input_png: Path, output_svg: Path, preset: str):
    params = preset_to_vtracer(preset)
    vtracer.convert_image_to_svg_py(
        str(input_png),
        str(output_svg),
        colormode="color",
        hierarchical="stacked",
        mode="spline",
        **params,
    )


def run_potrace_line_art(input_png: Path, output_svg: Path, line_threshold: int = 140):
    img = Image.open(input_png).convert("RGBA")
    alpha = img.getchannel("A")
    rgb = img.convert("RGB")
    gray = rgb.convert("L")

    # build black line mask by combining dark grayscale and alpha support
    gray_arr = np.array(gray)
    alpha_arr = np.array(alpha)
    line = ((gray_arr < line_threshold) & (alpha_arr > 0)).astype(np.uint8) * 255
    line_img = Image.fromarray(line, mode="L")
    line_img = line_img.filter(ImageFilter.MaxFilter(3)).filter(ImageFilter.MinFilter(3))

    with tempfile.TemporaryDirectory() as tmp:
        pbm = Path(tmp) / "line.pbm"
        line_img.convert("1").save(pbm)
        cmd = [
            "potrace", str(pbm), "-s", "-o", str(output_svg),
            "--turdsize", "2", "--alphamax", "1.0", "--opttolerance", "0.2", "--turnpolicy", "minority", "--longcurve"
        ]
        subprocess.run(cmd, check=True)


def merge_svgs(color_svg_path: Path, line_svg_path: Path, merged_svg_path: Path):
    color_svg = color_svg_path.read_text(encoding="utf-8", errors="ignore")
    line_svg = line_svg_path.read_text(encoding="utf-8", errors="ignore")

    def inner(svg_text: str) -> str:
        start = svg_text.find(">")
        end = svg_text.rfind("</svg>")
        if start == -1 or end == -1:
            return svg_text
        return svg_text[start + 1:end]

    root_start = color_svg.find(">")
    root_open = color_svg[: root_start + 1]
    merged = root_open + inner(color_svg) + '\n<g opacity="1">' + inner(line_svg) + '</g>\n</svg>'
    merged_svg_path.write_text(merged, encoding="utf-8")


def make_outputs(preprocessed: Image.Image, preset: str = "balanced") -> Tuple[str, str, str]:
    job_id = next(tempfile._get_candidate_names())
    out_dir = OUTPUT_DIR / job_id
    out_dir.mkdir(parents=True, exist_ok=True)

    png_path = out_dir / "preprocessed.png"
    color_svg_path = out_dir / "color_vtracer.svg"
    line_svg_path = out_dir / "line_potrace.svg"
    hybrid_svg_path = out_dir / "hybrid_output.svg"
    zip_path = out_dir / "results.zip"

    preprocessed.save(png_path)
    run_vtracer(png_path, color_svg_path, preset)
    run_potrace_line_art(png_path, line_svg_path)
    merge_svgs(color_svg_path, line_svg_path, hybrid_svg_path)

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.write(png_path, arcname=png_path.name)
        z.write(color_svg_path, arcname=color_svg_path.name)
        z.write(line_svg_path, arcname=line_svg_path.name)
        z.write(hybrid_svg_path, arcname=hybrid_svg_path.name)

    return job_id, str(out_dir.relative_to(OUTPUT_DIR)), zip_path.name


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/vectorize", response_class=HTMLResponse)
async def vectorize(
    request: Request,
    image: UploadFile = File(...),
    preset: str = Form("balanced"),
    remove_bg: str = Form("on"),
    halo_fix: str = Form("on"),
    max_side: int = Form(1800),
):
    try:
        src = pil_from_upload(image)
        preprocessed = preprocess_image(src, max_side=max_side, remove_bg=(remove_bg == "on"), halo_fix=(halo_fix == "on"))
        job_id, rel_dir, zip_name = make_outputs(preprocessed, preset=preset)
        result = {
            "job_id": job_id,
            "preview_png": f"/download/{job_id}/preprocessed.png",
            "color_svg": f"/download/{job_id}/color_vtracer.svg",
            "line_svg": f"/download/{job_id}/line_potrace.svg",
            "hybrid_svg": f"/download/{job_id}/hybrid_output.svg",
            "zip_url": f"/download/{job_id}/{zip_name}",
        }
        return templates.TemplateResponse("index.html", {"request": request, "result": result, "preset": preset, "remove_bg": remove_bg, "halo_fix": halo_fix, "max_side": max_side})
    except Exception as e:
        return templates.TemplateResponse("index.html", {"request": request, "error": str(e), "preset": preset, "remove_bg": remove_bg, "halo_fix": halo_fix, "max_side": max_side})


@app.get("/download/{job_id}/{filename}")
async def download_file(job_id: str, filename: str):
    path = OUTPUT_DIR / job_id / filename
    if not path.exists():
        return HTMLResponse("file not found", status_code=404)
    media_type = None
    if filename.endswith(".svg"):
        media_type = "image/svg+xml"
    elif filename.endswith(".png"):
        media_type = "image/png"
    elif filename.endswith(".zip"):
        media_type = "application/zip"
    return FileResponse(str(path), media_type=media_type, filename=filename)
